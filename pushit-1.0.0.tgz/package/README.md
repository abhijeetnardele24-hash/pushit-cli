# pushit 🚀

A complete, production-ready CLI tool that lets you manage your entire GitHub workflow interactively from the terminal. Zero browser needed after initial setup!

## Features

- 🆕 **Create new repository**: Interactively create a repo, add README/License/gitignore, and push in one go.
- 📤 **Commit & Push**: Smart commit message suggestions and one-click pushing.
- 📋 **List my repositories**: View a formatted table of your repos and manage them (rename, delete, toggle visibility).
- 🌿 **Manage branches**: Create, switch, and delete branches easily.
- 🔀 **Pull Requests**: Create and view open Pull Requests right from your terminal.
- 📝 **Generate README**: Bootstrap a professional README.md.
- ⚙️ **Settings**: Manage your GitHub credentials securely.

## Installation

Install globally using npm:

\`\`\`bash
npm install -g pushit
\`\`\`

## Usage

Simply run:

\`\`\`bash
pushit
\`\`\`

On your first run, you'll be asked for your GitHub Personal Access Token (with \`repo\`, \`delete_repo\`, and \`user\` scopes). It will be saved securely in your OS keychain/config store and you won't be prompted again.

## Requirements

- Node.js v18+

## License

MIT
