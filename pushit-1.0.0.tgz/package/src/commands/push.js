import { select, text, isCancel, spinner, note, outro } from '@clack/prompts';
import chalk from 'chalk';
import { getGit, isRepo } from '../lib/git.js';

export default async function() {
  const repoExists = await isRepo();
  if (!repoExists) {
    console.log(chalk.red('No git repo found in this folder. Use Create New Repo first.'));
    await text({ message: 'Press Enter to return to menu...' });
    return;
  }

  const git = getGit();
  const s = spinner();
  s.start('Checking for changes...');
  const status = await git.status();
  s.stop();

  if (status.files.length === 0) {
    console.log(chalk.yellow('Nothing to commit. Everything is up to date.'));
    await text({ message: 'Press Enter to return to menu...' });
    return;
  }

  console.log(chalk.cyan('\nChanged files:'));
  status.files.forEach(file => {
    let type = file.index === '?' ? 'A' : file.index.trim() || file.working_dir.trim();
    if (type === '??') type = 'A';
    console.log(`  ${chalk.yellow(type.padEnd(2))} ${file.path}`);
  });
  console.log();

  const fileName = status.files[0].path;
  const suggestions = [
    { value: `Update ${fileName}`, label: `Update ${fileName}` },
    { value: `Add ${fileName}`, label: `Add ${fileName}` },
    { value: 'custom', label: 'Write my own' },
    { value: 'cancel', label: 'Cancel' }
  ];

  const selection = await select({
    message: 'Commit message:',
    options: suggestions
  });

  if (isCancel(selection) || selection === 'cancel') return;

  let message = selection;
  if (selection === 'custom') {
    message = await text({
      message: 'Enter commit message:'
    });
    if (isCancel(message)) return;
  }

  s.start('Committing and pushing...');
  try {
    await git.add('.');
    s.message('Staged all changes');
    
    await git.commit(message);
    s.message(`Committed: "${message}"`);
    
    const branchInfo = await git.branchLocal();
    const branch = branchInfo.current;
    
    await git.push(['-u', 'origin', branch]);
    s.stop(chalk.green(`✓ Pushed to ${branch}`));
    
    await text({ message: 'Press Enter to return to menu...' });
  } catch (err) {
    s.stop(chalk.red('Failed'));
    console.error(chalk.red(err.message));
    await text({ message: 'Press Enter to return to menu...' });
  }
}
