import { select, text, isCancel, spinner, note } from '@clack/prompts';
import chalk from 'chalk';
import Table from 'cli-table3';
import open from 'open';
import { getOctokit } from '../lib/github.js';
import { getUsername } from '../lib/config.js';

function timeAgo(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now - date) / 1000);
  
  let interval = Math.floor(seconds / 31536000);
  if (interval >= 1) return interval + " year" + (interval === 1 ? "" : "s") + " ago";
  interval = Math.floor(seconds / 2592000);
  if (interval >= 1) return interval + " month" + (interval === 1 ? "" : "s") + " ago";
  interval = Math.floor(seconds / 86400);
  if (interval >= 1) return interval + " day" + (interval === 1 ? "" : "s") + " ago";
  interval = Math.floor(seconds / 3600);
  if (interval >= 1) return interval + " hour" + (interval === 1 ? "" : "s") + " ago";
  interval = Math.floor(seconds / 60);
  if (interval >= 1) return interval + " minute" + (interval === 1 ? "" : "s") + " ago";
  return Math.floor(seconds) + " seconds ago";
}

export default async function listRepos() {
  const octokit = getOctokit();
  const s = spinner();
  s.start('Fetching repositories...');

  try {
    const repos = await octokit.paginate(octokit.rest.repos.listForAuthenticatedUser, {
      sort: 'updated',
      direction: 'desc',
      per_page: 100
    });
    s.stop();

    if (repos.length === 0) {
      console.log(chalk.yellow('You have no repositories.'));
      await text({ message: 'Press Enter to return to menu...' });
      return;
    }

    const table = new Table({
      head: ['NAME', 'VISIBILITY', 'STARS', 'UPDATED'],
      style: {
        head: ['cyan'],
        border: ['gray']
      }
    });

    repos.forEach(repo => {
      table.push([
        repo.name,
        repo.private ? 'Private' : 'Public',
        repo.private ? '—' : repo.stargazers_count,
        timeAgo(repo.updated_at)
      ]);
    });

    console.log(table.toString());
    console.log();

    const repoSelection = await select({
      message: 'Select a repository to manage:',
      options: [
        ...repos.map(r => ({ value: r, label: r.name })),
        { value: 'back', label: '⬅️  Back to main menu' }
      ]
    });

    if (isCancel(repoSelection) || repoSelection === 'back') return;

    await manageRepo(repoSelection);

  } catch (err) {
    s.stop(chalk.red('Failed to fetch repositories'));
    console.error(chalk.red(err.message));
    await text({ message: 'Press Enter to return to menu...' });
  }
}

async function manageRepo(repo) {
  const action = await select({
    message: `Manage ${repo.name}:`,
    options: [
      { value: 'open', label: '🌐 Open in browser' },
      { value: 'rename', label: '✏️  Rename this repo' },
      { value: 'toggle', label: repo.private ? '🔓 Make Public' : '🔒 Make Private' },
      { value: 'delete', label: '❌ Delete this repo' },
      { value: 'back', label: '⬅️  Back' }
    ]
  });

  if (isCancel(action) || action === 'back') return listRepos();

  const octokit = getOctokit();
  const username = getUsername();

  if (action === 'open') {
    await open(repo.html_url);
    return manageRepo(repo);
  }

  if (action === 'delete') {
    const confirmName = await text({
      message: `Type "${repo.name}" to confirm deletion:`
    });
    if (isCancel(confirmName)) return manageRepo(repo);
    
    if (confirmName === repo.name) {
      const s = spinner();
      s.start('Deleting repository...');
      try {
        await octokit.rest.repos.delete({
          owner: username,
          repo: repo.name
        });
        s.stop(chalk.green(`✓ Deleted ${repo.name}`));
        await text({ message: 'Press Enter to return...' });
        return listRepos();
      } catch (err) {
        s.stop(chalk.red('Failed to delete'));
        console.error(chalk.red(err.message));
        await text({ message: 'Press Enter to return...' });
        return manageRepo(repo);
      }
    } else {
      console.log(chalk.red('Name did not match. Deletion cancelled.'));
      await text({ message: 'Press Enter to return...' });
      return manageRepo(repo);
    }
  }

  if (action === 'rename') {
    const newName = await text({
      message: 'New repository name:',
      defaultValue: repo.name
    });
    if (isCancel(newName) || !newName || newName === repo.name) return manageRepo(repo);

    const s = spinner();
    s.start('Renaming repository...');
    try {
      const { data: updated } = await octokit.rest.repos.update({
        owner: username,
        repo: repo.name,
        name: newName
      });
      s.stop(chalk.green(`✓ Renamed to ${updated.name}`));
      await text({ message: 'Press Enter to return...' });
      return manageRepo(updated);
    } catch (err) {
      s.stop(chalk.red('Failed to rename'));
      console.error(chalk.red(err.message));
      await text({ message: 'Press Enter to return...' });
      return manageRepo(repo);
    }
  }

  if (action === 'toggle') {
    const s = spinner();
    const newVisibility = !repo.private;
    s.start(`Making repository ${newVisibility ? 'Private' : 'Public'}...`);
    try {
      const { data: updated } = await octokit.rest.repos.update({
        owner: username,
        repo: repo.name,
        private: newVisibility
      });
      s.stop(chalk.green(`✓ Changed visibility to ${newVisibility ? 'Private' : 'Public'}`));
      await text({ message: 'Press Enter to return...' });
      return manageRepo(updated);
    } catch (err) {
      s.stop(chalk.red('Failed to change visibility'));
      console.error(chalk.red(err.message));
      await text({ message: 'Press Enter to return...' });
      return manageRepo(repo);
    }
  }
}
