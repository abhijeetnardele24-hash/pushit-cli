#!/usr/bin/env node

import { intro, outro, text, password, isCancel, spinner, note, select } from '@clack/prompts';
import chalk from 'chalk';
import { getToken, setToken, setUsername, getUsername } from './lib/config.js';
import { validateToken } from './lib/github.js';

async function checkAuth() {
  let token = getToken();
  let username = getUsername();

  if (!token) {
    note('Direct link: https://github.com/settings/tokens\nRequired scopes: repo, delete_repo, user', 'GitHub Personal Access Token needed');
    
    let validUser = null;
    
    while (!validUser) {
      username = await text({
        message: 'Enter your GitHub username',
        placeholder: 'octocat',
      });
      if (isCancel(username)) {
        outro('Setup cancelled');
        process.exit(0);
      }
      
      token = await password({
        message: 'Enter your GitHub Personal Access Token',
        mask: '*'
      });
      if (isCancel(token)) {
        outro('Setup cancelled');
        process.exit(0);
      }

      const s = spinner();
      s.start('Validating token...');
      
      validUser = await validateToken(token);
      
      if (!validUser) {
        s.stop('Invalid token or missing permissions. Please try again.');
        console.log(chalk.red('Make sure the token has "repo", "delete_repo", and "user" scopes.'));
      } else {
        s.stop(chalk.green(`Success! Authenticated as ${validUser.name || validUser.login} with ${validUser.public_repos} public repos.`));
        setToken(token);
        setUsername(username);
        console.log(chalk.green('Credentials saved. You won\'t be asked again.'));
      }
    }
  } else {
    // Silent validation on subsequent runs
    const validUser = await validateToken(token);
    if (!validUser) {
        console.log(chalk.red('Your saved GitHub token is invalid or expired.'));
        setToken(null);
        setUsername(null);
        return checkAuth(); // recurse to ask again
    }
  }
}

async function mainMenu() {
  const username = getUsername();
  
  const action = await select({
    message: 'What do you want to do?',
    options: [
      { value: 'new', label: '🆕  Create new repository' },
      { value: 'push', label: '📤  Commit & Push current folder' },
      { value: 'list', label: '📋  List my repositories' },
      { value: 'branch', label: '🌿  Manage branches' },
      { value: 'pr', label: '🔀  Pull Requests' },
      { value: 'readme', label: '📝  Generate README' },
      { value: 'settings', label: '⚙️   Settings' },
      { value: 'exit', label: '🚪  Exit' }
    ]
  });

  if (isCancel(action) || action === 'exit') {
    outro('Goodbye!');
    process.exit(0);
  }

  // Route to commands
  switch (action) {
    case 'new':
      await import('./commands/new.js').then(m => m.default());
      break;
    case 'push':
      await import('./commands/push.js').then(m => m.default());
      break;
    case 'list':
      await import('./commands/list.js').then(m => m.default());
      break;
    case 'branch':
      await import('./commands/branch.js').then(m => m.default());
      break;
    case 'pr':
      await import('./commands/pr.js').then(m => m.default());
      break;
    case 'readme':
      await import('./commands/readme.js').then(m => m.default());
      break;
    case 'settings':
      await import('./commands/settings.js').then(m => m.default());
      break;
  }
  
  // Return to main menu after action completes
  await mainMenu();
}

async function main() {
  // Try to get username for banner, if not set use default
  const userStr = getUsername() || 'GitHub CLI';
  intro(chalk.bgCyan.black(` PUSHIT v1.0.0 `) + chalk.dim(`\n [${userStr}] · GitHub CLI `));
  
  await checkAuth();

  await mainMenu();
}

main().catch(console.error);
